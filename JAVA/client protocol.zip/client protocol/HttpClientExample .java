import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class HttpClientExample {

    public static void main(String[] args) {
        try {
            // 1. Create the HttpClient (can be reused for multiple requests)
            HttpClient client = HttpClient.newHttpClient();

            // 2. Build the GET request to GitHub API (for example, user info)
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://api.github.com/users/octocat"))
                    .GET()
                    .build();

            // 3. Send the request and get the response synchronously
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            // 4. Print status code and response body
            System.out.println("Status code: " + response.statusCode());
            System.out.println("Response body: " + response.body());

        } catch (Exception e) {
            System.err.println("Request failed: " + e.getMessage());
        }
    }
}
